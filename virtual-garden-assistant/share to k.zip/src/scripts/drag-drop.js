import { addGardenElement } from './garden-renderer.js';
import { state, gardenCanvas, GRID_SIZE } from './main.js';

// Initialize drag and drop functionality
document.addEventListener('DOMContentLoaded', () => {
  initDragAndDrop();
});

/**
 * Initialize drag and drop functionality
 */
function initDragAndDrop() {
  const elementsContainer = document.querySelector('.elements-container');
  const gardenCanvas = document.getElementById('garden-canvas');

  if (!elementsContainer || !gardenCanvas) {
    console.error('Required DOM elements not found');
    return;
  }

  // Make garden canvas a drop target
  makeDropTarget(gardenCanvas);

  // Make element items draggable
  elementsContainer.addEventListener('click', (event) => {
    const draggableItem = event.target.closest('.draggable');
    if (draggableItem && !draggableItem.hasAttribute('draggable')) {
      makeElementDraggable(draggableItem);
    }
  });

  // Observe for new elements dynamically added to the container
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1 && node.classList.contains('draggable')) {
            makeElementDraggable(node);
          }
        });
      }
    });
  });

  // Start observing the elements container
  observer.observe(elementsContainer, { childList: true, subtree: true });
}

/**
 * Make an element draggable
 * @param {HTMLElement} element - Element to make draggable
 */
function makeElementDraggable(element) {
  element.setAttribute('draggable', 'true');

  element.addEventListener('dragstart', (e) => {
    // Create a ghost image
    const ghostImage = element.cloneNode(true);
    ghostImage.style.position = 'absolute';
    ghostImage.style.top = '-1000px';
    ghostImage.style.opacity = '0.5';
    document.body.appendChild(ghostImage);

    // Set drag data and image
    const elementType = element.dataset.elementType;
    const elementId = element.dataset.elementId;

    e.dataTransfer.setData('text/plain', JSON.stringify({
      type: elementType,
      id: elementId
    }));

    e.dataTransfer.effectAllowed = 'copy';
    e.dataTransfer.setDragImage(ghostImage, 30, 30);

    // Clean up ghost image after dragging
    setTimeout(() => {
      document.body.removeChild(ghostImage);
    }, 0);

    // Update state
    state.isDragging = true;
  });

  element.addEventListener('dragend', () => {
    // Update state
    state.isDragging = false;
  });
}

/**
 * Make an element a drop target
 * @param {HTMLElement} element - Element to make a drop target
 */
function makeDropTarget(element) {
  element.addEventListener('dragover', (e) => {
    // Prevent default to allow drop
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';

    // Add visual feedback
    element.classList.add('drop-active');
  });

  element.addEventListener('dragleave', (e) => {
    // Only remove visual feedback if we're leaving the element itself
    if (!element.contains(e.relatedTarget)) {
      element.classList.remove('drop-active');
    }
  });

  element.addEventListener('drop', (e) => {
    e.preventDefault();

    // Remove visual feedback
    element.classList.remove('drop-active');

    // Get the drop position in the canvas
    const rect = element.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Convert to scene coordinates
    const sceneX = (x / rect.width) * 30 - 15; // 30m wide garden, centered at 0
    const sceneZ = (y / rect.height) * 30 - 15; // 30m deep garden, centered at 0

    // Snap to grid
    const snappedX = state.snapToGrid ? Math.round(sceneX / GRID_SIZE) * GRID_SIZE : sceneX;
    const snappedZ = state.snapToGrid ? Math.round(sceneZ / GRID_SIZE) * GRID_SIZE : sceneZ;

    try {
      // Get the dropped element data
      const elementData = JSON.parse(e.dataTransfer.getData('text/plain'));
      console.log('Dropped element data:', elementData);

      // Import the necessary functions and objects
      import('./element-loader.js').then((module) => {
        // Get full element data
        const elementTemplate = module.getElementById(elementData.id);
        console.log('Element template:', elementTemplate);

        if (elementTemplate) {
          // Create a new element instance
          const newElement = {
            ...elementTemplate,
            id: Date.now().toString(), // Generate a unique ID
            position: { x: snappedX, y: 0, z: snappedZ }, // Position at drop location
            rotation: 0,
            properties: { ...elementTemplate.properties } // Clone properties
          };

          console.log('Adding new element to garden:', newElement);
          
          // Add element to the garden
          addGardenElement(newElement);
        } else {
          console.error('Element template not found for ID:', elementData.id);
        }
      });
    } catch (error) {
      console.error('Error handling drop:', error);
    }
  });
}

// Export the functions
export {
  initDragAndDrop,
  makeElementDraggable,
  makeDropTarget
};
