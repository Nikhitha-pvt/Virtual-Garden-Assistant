// Import dependencies
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { state, GARDEN_SIZE, GRID_SIZE } from './main.js';

// Private variables
let scene, camera, renderer, controls;
let gridHelper, groundMesh;
let elementMeshes = new Map(); // Map element id to its mesh
let isDragging = false;
let draggedElement = null;
let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();
let isInitialized = false;
let currentMode = '2d'; // '2d' or '3d'
let modelCache = new Map(); // Cache for loaded 3D models

// Setup garden canvas
export function setupGardenCanvas(canvasContainer, gardenSize, gridSize, appState) {
  if (isInitialized) return;

  console.log('Setting up garden canvas...');

  // Create scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xe9e9e9);

  // Create renderer
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(canvasContainer.clientWidth, canvasContainer.clientHeight);
  renderer.shadowMap.enabled = true;
  canvasContainer.appendChild(renderer.domElement);

  // Create camera for 2D view (orthographic)
  setupCameras();

  // Add grid
  setupGrid(gardenSize, gridSize);

  // Add ground
  setupGround(gardenSize);

  // Add ambient light
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  // Add directional light (sun)
  const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
  directionalLight.position.set(gardenSize / 2, gardenSize, gardenSize / 2);
  directionalLight.castShadow = true;

  // Adjust shadow properties for better quality
  directionalLight.shadow.mapSize.width = 2048;
  directionalLight.shadow.mapSize.height = 2048;
  directionalLight.shadow.camera.left = -gardenSize;
  directionalLight.shadow.camera.right = gardenSize;
  directionalLight.shadow.camera.top = gardenSize;
  directionalLight.shadow.camera.bottom = -gardenSize;
  scene.add(directionalLight);

  // Add event listeners
  window.addEventListener('resize', onWindowResize);
  renderer.domElement.addEventListener('mousedown', onMouseDown);
  renderer.domElement.addEventListener('mousemove', onMouseMove);
  renderer.domElement.addEventListener('mouseup', onMouseUp);

  // Start rendering
  isInitialized = true;
  animate();

  console.log('Garden canvas setup complete.');
}

// Setup cameras
function setupCameras() {
  // Orthographic camera for 2D view
  const aspect = renderer.domElement.clientWidth / renderer.domElement.clientHeight;
  const frustumSize = GARDEN_SIZE * 1.1; // slightly larger than garden size

  camera = new THREE.OrthographicCamera(
    frustumSize * aspect / -2,
    frustumSize * aspect / 2,
    frustumSize / 2,
    frustumSize / -2,
    0.1,
    1000
  );

  camera.position.set(0, frustumSize, 0);
  camera.lookAt(0, 0, 0);

  // Set up orbit controls
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.1;
  controls.screenSpacePanning = true;

  // Limit orbit controls for 2D view
  controls.minPolarAngle = 0;
  controls.maxPolarAngle = Math.PI / 2;
  controls.enableRotate = false;
}

// Setup grid
function setupGrid(size, gridSize) {
  // Remove existing grid if it exists
  if (gridHelper) scene.remove(gridHelper);

  // Create grid helper
  gridHelper = new THREE.GridHelper(size, size / gridSize, 0x888888, 0xcccccc);
  gridHelper.rotation.x = Math.PI / 2; // lay flat on xz plane
  gridHelper.position.y = 0.01; // slightly above ground to avoid z-fighting
  scene.add(gridHelper);
}

// Setup ground plane
function setupGround(size) {
  // Create ground plane
  const groundGeometry = new THREE.PlaneGeometry(size, size);
  const groundMaterial = new THREE.MeshStandardMaterial({
    color: 0x8BC34A, // green grass color
    roughness: 0.8,
    metalness: 0.1
  });

  groundMesh = new THREE.Mesh(groundGeometry, groundMaterial);
  groundMesh.rotation.x = -Math.PI / 2; // lay flat
  groundMesh.receiveShadow = true;
  scene.add(groundMesh);
}

// Handle window resize
function onWindowResize() {
  const container = renderer.domElement.parentElement;
  const aspect = container.clientWidth / container.clientHeight;

  if (currentMode === '2d') {
    // Update orthographic camera
    const frustumSize = GARDEN_SIZE * 1.1;
    camera.left = frustumSize * aspect / -2;
    camera.right = frustumSize * aspect / 2;
    camera.top = frustumSize / 2;
    camera.bottom = frustumSize / -2;
  } else {
    // Update perspective camera
    camera.aspect = aspect;
  }

  camera.updateProjectionMatrix();
  renderer.setSize(container.clientWidth, container.clientHeight);
}

// Animation loop
function animate() {
  requestAnimationFrame(animate);

  controls.update();
  renderer.render(scene, camera);
}

// Switch between 2D and 3D views
export function switchToView(mode, appState) {
  if (mode === currentMode) return;

  currentMode = mode;

  if (mode === '2d') {
    // Switch to orthographic camera (top-down view)
    const aspect = renderer.domElement.clientWidth / renderer.domElement.clientHeight;
    const frustumSize = GARDEN_SIZE * 1.1;

    camera = new THREE.OrthographicCamera(
      frustumSize * aspect / -2,
      frustumSize * aspect / 2,
      frustumSize / 2,
      frustumSize / -2,
      0.1,
      1000
    );

    camera.position.set(0, frustumSize, 0);
    camera.lookAt(0, 0, 0);

    // Update controls
    controls.dispose();
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.1;
    controls.screenSpacePanning = true;
    controls.enableRotate = false;
  } else {
    // Switch to perspective camera (3D view)
    const aspect = renderer.domElement.clientWidth / renderer.domElement.clientHeight;

    camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
    camera.position.set(GARDEN_SIZE / 2, GARDEN_SIZE / 2, GARDEN_SIZE / 2);
    camera.lookAt(0, 0, 0);

    // Update controls
    controls.dispose();
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.1;
    controls.screenSpacePanning = true;
    controls.minDistance = 1;
    controls.maxDistance = GARDEN_SIZE * 1.5;
  }

  // Update the application state
  appState.currentView = mode;
}

// Mouse interaction handlers
function onMouseDown(event) {
  event.preventDefault();

  // Update mouse coordinates
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  // Check if we clicked on an element
  raycaster.setFromCamera(mouse, camera);

  // Get all meshes in the scene that represent elements
  const meshes = [];
  elementMeshes.forEach(mesh => {
    meshes.push(mesh);
  });

  const intersects = raycaster.intersectObjects(meshes);

  if (intersects.length > 0) {
    // We clicked on an element
    const selectedMesh = intersects[0].object;

    // Find the element that owns this mesh
    let selectedElementId = null;
    elementMeshes.forEach((mesh, id) => {
      if (mesh === selectedMesh || mesh.children.includes(selectedMesh)) {
        selectedElementId = id;
      }
    });

    if (selectedElementId) {
      // Find the element in the garden elements
      const selectedElement = state.gardenElements.find(el => el.id === selectedElementId);
      if (selectedElement) {
        // Mark as dragging
        isDragging = true;
        draggedElement = selectedElement;
        state.selectedElement = selectedElement;

        // Show element properties in UI
        showElementProperties(selectedElement);
      }
    }
  } else {
    // Clicked on empty space, deselect current element
    state.selectedElement = null;
    hideElementProperties();
  }
}

function onMouseMove(event) {
  if (!isDragging || !draggedElement) return;

  // Update mouse coordinates
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  // Use raycaster to get intersection with ground plane
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObject(groundMesh);

  if (intersects.length > 0) {
    const intersectionPoint = intersects[0].point;

    // If snap to grid is enabled, snap to grid
    if (state.snapToGrid) {
      intersectionPoint.x = Math.round(intersectionPoint.x / GRID_SIZE) * GRID_SIZE;
      intersectionPoint.z = Math.round(intersectionPoint.z / GRID_SIZE) * GRID_SIZE;
    }

    // Update the element position
    draggedElement.position = {
      x: intersectionPoint.x,
      y: intersectionPoint.y,
      z: intersectionPoint.z
    };

    // Update the mesh position
    const mesh = elementMeshes.get(draggedElement.id);
    if (mesh) {
      mesh.position.copy(intersectionPoint);
    }
  }
}

function onMouseUp(event) {
  if (isDragging && draggedElement) {
    // Register the change for undo/redo
    import('./main.js').then(module => {
      module.registerChange();
    });
  }

  isDragging = false;
  draggedElement = null;
}

// Grid visibility toggle
export function updateGridVisibility(isVisible) {
  if (gridHelper) {
    gridHelper.visible = isVisible;
  }
}

// Zoom garden view
export function zoomGarden(zoomFactor) {
  if (currentMode === '2d') {
    // Adjust orthographic camera zoom
    const currentZoom = camera.zoom;
    const newZoom = Math.max(0.5, Math.min(3, currentZoom + zoomFactor));
    camera.zoom = newZoom;
    camera.updateProjectionMatrix();
  } else {
    // Adjust perspective camera position
    const zoomSpeed = 2;
    const cameraDirection = new THREE.Vector3();
    camera.getWorldDirection(cameraDirection);
    camera.position.addScaledVector(cameraDirection, zoomFactor * zoomSpeed);
    controls.update();
  }
}

// Element properties panel handling
function showElementProperties(element) {
  const propertiesPanel = document.querySelector('.properties-panel');
  const propertiesForm = document.querySelector('.properties-form');

  // Clear previous properties
  propertiesForm.innerHTML = '';

  // Create form fields for element properties
  for (const [key, value] of Object.entries(element.properties || {})) {
    const formGroup = document.createElement('div');
    formGroup.className = 'mb-2';

    const label = document.createElement('label');
    label.className = 'form-label';
    label.textContent = key.charAt(0).toUpperCase() + key.slice(1);

    const input = document.createElement('input');
    input.className = 'form-control form-control-sm';
    input.value = value;
    input.dataset.property = key;

    // Add event listener to update property when changed
    input.addEventListener('change', (e) => {
      element.properties[key] = e.target.value;
      updateElementVisual(element);
    });

    formGroup.appendChild(label);
    formGroup.appendChild(input);
    propertiesForm.appendChild(formGroup);
  }

  // Add rotation control
  const rotationGroup = document.createElement('div');
  rotationGroup.className = 'mb-2';

  const rotationLabel = document.createElement('label');
  rotationLabel.className = 'form-label';
  rotationLabel.textContent = 'Rotation (degrees)';

  const rotationInput = document.createElement('input');
  rotationInput.className = 'form-control form-control-sm';
  rotationInput.type = 'number';
  rotationInput.min = '0';
  rotationInput.max = '360';
  rotationInput.value = element.rotation || 0;

  rotationInput.addEventListener('change', (e) => {
    element.rotation = parseFloat(e.target.value);
    updateElementVisual(element);
  });

  rotationGroup.appendChild(rotationLabel);
  rotationGroup.appendChild(rotationInput);
  propertiesForm.appendChild(rotationGroup);

  // Add delete button
  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'btn btn-sm btn-danger mt-2';
  deleteBtn.textContent = 'Delete Element';
  deleteBtn.addEventListener('click', () => {
    removeElement(element);
  });

  propertiesForm.appendChild(deleteBtn);

  // Show the panel
  propertiesPanel.style.display = 'block';
}

function hideElementProperties() {
  const propertiesPanel = document.querySelector('.properties-panel');
  propertiesPanel.style.display = 'none';
}

// Add a new element to the garden
export function addGardenElement(element) {
  console.log('Adding garden element:', element);
  
  // Generate a unique ID if not provided
  if (!element.id) {
    element.id = Date.now().toString();
  }

  // Add to state
  state.gardenElements.push(element);
  console.log('Updated garden elements:', state.gardenElements);

  // Create and add the visual representation
  createElementVisual(element);

  // Register the change for undo/redo
  import('./main.js').then(module => {
    module.registerChange();
  });

  return element;
}

// Remove an element from the garden
export function removeElement(element) {
  // Remove from state
  const index = state.gardenElements.findIndex(el => el.id === element.id);
  if (index !== -1) {
    state.gardenElements.splice(index, 1);
  }

  // Remove from scene
  const mesh = elementMeshes.get(element.id);
  if (mesh) {
    scene.remove(mesh);
    elementMeshes.delete(element.id);
  }

  // Hide properties panel
  hideElementProperties();

  // Register the change for undo/redo
  import('./main.js').then(module => {
    module.registerChange();
  });
}

// Create visual representation for an element
function createElementVisual(element) {
  console.log('Creating visual for element:', element);
  let mesh;

  // Check if it's a 3D model
  if (element.modelPath) {
    // Load 3D model
    loadModel(element.modelPath)
      .then(model => {
        // Set position, rotation, scale
        model.position.set(
          element.position.x || 0,
          element.position.y || 0,
          element.position.z || 0
        );

        // Apply rotation
        if (element.rotation) {
          model.rotation.y = (element.rotation * Math.PI) / 180;
        }

        // Apply scale
        if (element.scale) {
          model.scale.set(element.scale, element.scale, element.scale);
        }

        // Add to scene
        scene.add(model);
        elementMeshes.set(element.id, model);
        console.log('Added 3D model to scene:', model);
      })
      .catch(error => {
        console.error('Error loading model:', error);
        // Fallback to a simple cube
        createFallbackVisual(element);
      });
  } else {
    // Create a simple shape based on the element type
    createSimpleVisual(element);
  }
}

// Create a simple visual for elements without 3D models
function createSimpleVisual(element) {
  console.log('Creating simple visual for element type:', element.type);
  let geometry, material, mesh;

  // Create geometry based on element type
  switch (element.type) {
    case 'surface':
      // Surface - flat plane
      geometry = new THREE.PlaneGeometry(
        element.properties?.width || 2,
        element.properties?.depth || 2
      );
      material = new THREE.MeshStandardMaterial({ 
        color: element.properties?.material === 'grass' ? 0x7CFC00 : 
               element.properties?.material === 'concrete' ? 0xC0C0C0 : 
               element.properties?.material === 'wood' ? 0xCD853F : 
               element.properties?.material === 'gravel' ? 0xD3D3D3 : 0x8B4513,
        side: THREE.DoubleSide
      });
      mesh = new THREE.Mesh(geometry, material);
      mesh.rotation.x = -Math.PI / 2; // lay flat
      break;

    case 'path':
      // Path - long rectangle
      geometry = new THREE.PlaneGeometry(
        element.properties?.width || 0.8,
        element.properties?.length || 3
      );
      material = new THREE.MeshStandardMaterial({ 
        color: element.properties?.material === 'brick' ? 0xB22222 : 
               element.properties?.material === 'stone' ? 0x808080 : 
               element.properties?.material === 'gravel' ? 0xD3D3D3 : 0x8B4513,
        side: THREE.DoubleSide
      });
      mesh = new THREE.Mesh(geometry, material);
      mesh.rotation.x = -Math.PI / 2; // lay flat
      break;

    case 'tree':
      // Simple tree - cone for foliage, cylinder for trunk
      const treeGroup = new THREE.Group();

      // Trunk
      const trunkGeometry = new THREE.CylinderGeometry(0.2, 0.2, 1, 8);
      const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x8B4513 });
      const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
      trunk.position.y = 0.5;
      treeGroup.add(trunk);

      // Foliage
      const foliageGeometry = new THREE.ConeGeometry(1, 2, 8);
      const foliageMaterial = new THREE.MeshStandardMaterial({ color: 0x228B22 });
      const foliage = new THREE.Mesh(foliageGeometry, foliageMaterial);
      foliage.position.y = 2;
      treeGroup.add(foliage);

      // Position, rotate, and add to scene
      treeGroup.position.set(
        element.position.x || 0,
        element.position.y || 0,
        element.position.z || 0
      );

      if (element.rotation) {
        treeGroup.rotation.y = (element.rotation * Math.PI) / 180;
      }

      treeGroup.castShadow = true;
      scene.add(treeGroup);
      elementMeshes.set(element.id, treeGroup);
      console.log('Added tree to scene:', treeGroup);
      return;

    case 'bush':
      // Simple bush - sphere
      geometry = new THREE.SphereGeometry(0.5, 16, 16);
      material = new THREE.MeshStandardMaterial({ color: 0x228B22 });
      mesh = new THREE.Mesh(geometry, material);
      mesh.position.y = 0.5;
      break;

    case 'flower':
      // Simple flower - small cylinder with sphere on top
      const flowerGroup = new THREE.Group();

      // Stem
      const stemGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.5, 8);
      const stemMaterial = new THREE.MeshStandardMaterial({ color: 0x228B22 });
      const stem = new THREE.Mesh(stemGeometry, stemMaterial);
      stem.position.y = 0.25;
      flowerGroup.add(stem);

      // Flower head
      const headGeometry = new THREE.SphereGeometry(0.15, 16, 16);
      const headMaterial = new THREE.MeshStandardMaterial({ 
        color: element.properties?.color === 'red' ? 0xFF0000 : 
               element.properties?.color === 'yellow' ? 0xFFFF00 : 
               element.properties?.color === 'blue' ? 0x0000FF : 
               element.properties?.color === 'purple' ? 0x800080 : 
               element.properties?.color === 'pink' ? 0xFFC0CB : 0xFFFFFF
      });
      const head = new THREE.Mesh(headGeometry, headMaterial);
      head.position.y = 0.5;
      flowerGroup.add(head);

      // Position, rotate, and add to scene
      flowerGroup.position.set(
        element.position.x || 0,
        element.position.y || 0,
        element.position.z || 0
      );

      if (element.rotation) {
        flowerGroup.rotation.y = (element.rotation * Math.PI) / 180;
      }

      flowerGroup.castShadow = true;
      scene.add(flowerGroup);
      elementMeshes.set(element.id, flowerGroup);
      console.log('Added flower to scene:', flowerGroup);
      return;

    case 'pond':
      // Simple pond - blue circle
      geometry = new THREE.CircleGeometry(element.properties?.radius || 1.5, 32);
      material = new THREE.MeshStandardMaterial({
        color: 0x4169E1,
        transparent: true,
        opacity: 0.7
      });
      mesh = new THREE.Mesh(geometry, material);
      mesh.rotation.x = -Math.PI / 2; // lay flat
      break;

    case 'house':
      // Simple house - cube with roof
      const houseGroup = new THREE.Group();

      // Base
      const baseGeometry = new THREE.BoxGeometry(
        element.properties?.width || 3,
        element.properties?.height || 2,
        element.properties?.depth || 3
      );
      const baseMaterial = new THREE.MeshStandardMaterial({ color: 0xE5E5E5 });
      const base = new THREE.Mesh(baseGeometry, baseMaterial);
      base.position.y = element.properties?.height / 2 || 1;
      houseGroup.add(base);

      // Roof
      const roofHeight = 1;
      const roofGeometry = new THREE.ConeGeometry(
        Math.sqrt(Math.pow(element.properties?.width || 3, 2) + Math.pow(element.properties?.depth || 3, 2)) / 2,
        roofHeight,
        4
      );
      const roofMaterial = new THREE.MeshStandardMaterial({ color: 0xA52A2A });
      const roof = new THREE.Mesh(roofGeometry, roofMaterial);
      roof.position.y = (element.properties?.height || 2) + roofHeight / 2;
      roof.rotation.y = Math.PI / 4; // Rotate to align with base
      houseGroup.add(roof);

      // Position, rotate, and add to scene
      houseGroup.position.set(
        element.position.x || 0,
        element.position.y || 0,
        element.position.z || 0
      );

      if (element.rotation) {
        houseGroup.rotation.y = (element.rotation * Math.PI) / 180;
      }

      houseGroup.castShadow = true;
      scene.add(houseGroup);
      elementMeshes.set(element.id, houseGroup);
      console.log('Added house to scene:', houseGroup);
      return;

    case 'plot':
      // Garden plot - brown rectangle
      geometry = new THREE.PlaneGeometry(
        element.properties?.width || 2,
        element.properties?.depth || 2
      );
      material = new THREE.MeshStandardMaterial({ 
        color: 0x8B4513,
        side: THREE.DoubleSide
      });
      mesh = new THREE.Mesh(geometry, material);
      mesh.rotation.x = -Math.PI / 2; // lay flat
      break;

    case 'furniture':
      // Generic furniture - low table or bench
      geometry = new THREE.BoxGeometry(
        element.properties?.width || 1.5,
        element.properties?.height || 0.4,
        element.properties?.depth || 0.8
      );
      material = new THREE.MeshStandardMaterial({ color: 0xCD853F });
      mesh = new THREE.Mesh(geometry, material);
      mesh.position.y = element.properties?.height / 2 || 0.2;
      break;

    default:
      // Generic placeholder - cube
      geometry = new THREE.BoxGeometry(1, 1, 1);
      material = new THREE.MeshStandardMaterial({ color: 0x888888 });
      mesh = new THREE.Mesh(geometry, material);
      mesh.position.y = 0.5;
      break;
  }

  // For types that create their own mesh and add it to the scene
  if (!mesh) return;

  // Position, rotate, and add to scene
  mesh.position.set(
    element.position.x || 0,
    element.position.y || 0,
    element.position.z || 0
  );

  if (element.rotation) {
    mesh.rotation.y = (element.rotation * Math.PI) / 180;
  }

  mesh.castShadow = true;
  mesh.receiveShadow = true;

  scene.add(mesh);
  elementMeshes.set(element.id, mesh);
  console.log('Added mesh to scene:', mesh);
}

// Create a fallback visual when model loading fails
function createFallbackVisual(element) {
  const geometry = new THREE.BoxGeometry(1, 1, 1);
  const material = new THREE.MeshStandardMaterial({ color: 0xFF0000 }); // Red to indicate error
  const mesh = new THREE.Mesh(geometry, material);

  mesh.position.set(
    element.position.x || 0,
    element.position.y || 0.5, // raise slightly to be visible
    element.position.z || 0
  );

  scene.add(mesh);
  elementMeshes.set(element.id, mesh);
}

// Load a 3D model
function loadModel(modelPath) {
  return new Promise((resolve, reject) => {
    // Check if model is already cached
    if (modelCache.has(modelPath)) {
      // Clone the cached model
      const cachedModel = modelCache.get(modelPath).clone();
      resolve(cachedModel);
      return;
    }

    // Load the model
    const loader = new GLTFLoader();
    loader.load(
      modelPath,
      (gltf) => {
        const model = gltf.scene;

        // Cache the model for future use
        modelCache.set(modelPath, model.clone());

        // Apply shadows to all meshes
        model.traverse((node) => {
          if (node.isMesh) {
            node.castShadow = true;
            node.receiveShadow = true;
          }
        });

        resolve(model);
      },
      undefined,
      (error) => {
        reject(error);
      }
    );
  });
}

// Update visual representation when element properties change
function updateElementVisual(element) {
  // Remove existing visual
  const existingMesh = elementMeshes.get(element.id);
  if (existingMesh) {
    scene.remove(existingMesh);
    elementMeshes.delete(element.id);
  }

  // Create new visual
  createElementVisual(element);
}

// Clear all elements from the scene
export function clearScene() {
  // Remove all element meshes
  elementMeshes.forEach((mesh) => {
    scene.remove(mesh);
  });

  elementMeshes.clear();
}

// Render all garden elements
export function renderGarden(elements) {
  // Clear existing elements
  clearScene();

  // Add each element
  if (elements && elements.length > 0) {
    elements.forEach(element => {
      createElementVisual(element);
    });
  }
}
